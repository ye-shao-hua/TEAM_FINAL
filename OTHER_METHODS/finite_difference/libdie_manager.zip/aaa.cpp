#include<iostream>
#include <mutex>
#include <syncstream>

template<class Func>
void for_ysh(int iters, Func func) {
#pragma omp parallel for num_threads(8)
    for(int i = 0; i < iters; ++i)
        func(i);
}

int main(){
    {
    std::osyncstream os{std::cout};
    for_ysh(5, [&](int i){
        for_ysh(5, [&](int j){
            os << i * 5 + j << ", ";
        });
        os << "\n";
    });
    }
}


